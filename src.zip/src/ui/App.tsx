// ============================================================================
// Casco da aplicação: header (equipe/ano/salvar), navegação e roteamento
// por fase da temporada. As telas vivem em /src/ui/telas.
// ============================================================================

import { CATALOGO } from '../state/catalogo';
import { useJogo, type Tela } from '../state/store';
import { formatarDinheiro } from './formatar';
import { Botao } from './componentes';
import { Calendario } from './telas/Calendario';
import { Campeonatos } from './telas/Campeonatos';
import { Escritorio } from './telas/Escritorio';
import { FimDeSemana } from './telas/FimDeSemana';
import { FimTemporada } from './telas/FimTemporada';
import { NovaCarreira } from './telas/NovaCarreira';

const NOME_FASE: Record<string, string> = {
  'pre-temporada': 'Pré-temporada',
  'gp-classificacao': 'Fim de semana de GP — classificação',
  'gp-estrategia': 'Fim de semana de GP — estratégia',
  'gp-corrida': 'Fim de semana de GP — corrida',
  'fim-temporada': 'Fim de temporada',
};

export default function App() {
  const { estado, tela, irPara, salvar, carregar, avisoSave } = useJogo();

  if (!estado) return <NovaCarreira />;

  const jogador = estado.equipes.find((e) => e.ehJogador)!;
  const patrocinador = CATALOGO.patrocinadores[jogador.patrocinadorId];

  const abas: { id: Tela; nome: string }[] = [
    { id: 'principal', nome: NOME_FASE[estado.fase] },
    { id: 'calendario', nome: 'Calendário' },
    { id: 'campeonatos', nome: 'Campeonatos' },
  ];

  return (
    <div className="min-h-screen">
      <header className="border-b border-borda bg-superficie">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center gap-x-6 gap-y-2 px-4 py-3">
          <span className="text-sm font-black uppercase tracking-[0.2em] text-acento">Projecto F1</span>
          <div className="flex items-baseline gap-3">
            <span className="font-semibold">{jogador.nome}</span>
            <span className="num text-sm text-mudo">Temporada {estado.ano}</span>
            <span className="text-sm text-mudo">Reputação <span className="num text-texto">{Math.round(jogador.reputacao)}</span></span>
            {patrocinador && (
              <span className="hidden text-sm text-mudo sm:inline">
                {patrocinador.nome} · <span className="num">{formatarDinheiro(patrocinador.aporte)}</span>
              </span>
            )}
          </div>
          <div className="ml-auto flex items-center gap-2">
            {avisoSave && <span className="text-sm text-positivo">{avisoSave}</span>}
            <Botao variante="secundario" onClick={salvar}>Salvar</Botao>
            <Botao variante="secundario" onClick={carregar}>Carregar</Botao>
          </div>
        </div>
        <nav className="mx-auto flex max-w-6xl gap-1 px-4">
          {abas.map((aba) => (
            <button
              key={aba.id}
              type="button"
              onClick={() => irPara(aba.id)}
              className={`rounded-t border-b-2 px-4 py-2 text-sm font-medium transition-colors ${
                tela === aba.id
                  ? 'border-acento text-texto'
                  : 'border-transparent text-mudo hover:text-texto'
              }`}
            >
              {aba.nome}
            </button>
          ))}
        </nav>
      </header>

      <main className="mx-auto max-w-6xl px-4 py-6">
        {tela === 'calendario' && <Calendario />}
        {tela === 'campeonatos' && <Campeonatos />}
        {tela === 'principal' && (
          <>
            {estado.fase === 'pre-temporada' && <Escritorio />}
            {(estado.fase === 'gp-classificacao' ||
              estado.fase === 'gp-estrategia' ||
              estado.fase === 'gp-corrida') && <FimDeSemana />}
            {estado.fase === 'fim-temporada' && <FimTemporada />}
          </>
        )}
      </main>
    </div>
  );
}
