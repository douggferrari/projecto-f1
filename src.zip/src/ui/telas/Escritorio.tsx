// ============================================================================
// Escritório / pré-temporada: contratos (motor, pilotos, patrocínio),
// slider de investimento e painel de orçamento sempre visível.
// ============================================================================

import { useMemo, useState } from 'react';
import type { DecisoesPreTemporada } from '../../engine/carreira';
import { anosRestantes, contratoVigente, criarContratoMotor, criarContratoPiloto, custoAnualMotor, salarioAnualPiloto } from '../../engine/contratos';
import { validarOrcamento } from '../../engine/orcamento';
import type { Equipe } from '../../engine/tipos';
import { CATALOGO } from '../../state/catalogo';
import { useJogo } from '../../state/store';
import { formatarDinheiro } from '../formatar';
import { Botao, Card, ListaErros, TierBadge } from '../componentes';

interface SelecaoContrato {
  id: string;
  duracao: number;
}

export function Escritorio() {
  const { estado, confirmarPreTemporada, erros } = useJogo();
  const jogador = estado!.equipes.find((e) => e.ehJogador)!;
  const ano = estado!.ano;
  const premiacao = estado!.premiacaoAnterior[jogador.id] ?? 0;

  const motorVigente = contratoVigente(jogador.contratoMotor, ano);
  const assentosVagos = ([0, 1] as const).filter((s) => !contratoVigente(jogador.pilotos[s], ano));

  // --- decisões locais (aplicadas só no confirmar) ---
  const [motorSel, setMotorSel] = useState<SelecaoContrato>({ id: jogador.contratoMotor.motorId, duracao: 2 });
  const [pilotosSel, setPilotosSel] = useState<Record<number, SelecaoContrato>>({});
  const [patrocinadorId, setPatrocinadorId] = useState(jogador.patrocinadorId);
  const [investimento, setInvestimento] = useState(0);

  // Equipe "prévia" com as seleções aplicadas — o painel de orçamento e a
  // validação usam as mesmas funções puras do motor
  const previa: Equipe = useMemo(() => {
    const eq = structuredClone(jogador);
    if (!motorVigente && CATALOGO.motores[motorSel.id]) {
      eq.contratoMotor = criarContratoMotor(CATALOGO.motores[motorSel.id], motorSel.duracao, ano);
    }
    for (const slot of assentosVagos) {
      const sel = pilotosSel[slot];
      if (sel && CATALOGO.pilotos[sel.id]) {
        eq.pilotos[slot] = criarContratoPiloto(CATALOGO.pilotos[sel.id], sel.duracao, ano);
      }
    }
    eq.patrocinadorId = patrocinadorId;
    return eq;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [jogador, motorSel, pilotosSel, patrocinadorId, ano]);

  const orcamento = validarOrcamento(previa, CATALOGO.patrocinadores, premiacao, investimento);
  const tetoInvestimento = Math.max(0, orcamento.receita - orcamento.gastosFixos);

  const confirmar = () => {
    const decisoes: DecisoesPreTemporada = {
      patrocinadorId,
      investimento,
      motor: motorVigente ? undefined : { motorId: motorSel.id, duracaoAnos: motorSel.duracao },
      pilotos: assentosVagos
        .filter((slot) => pilotosSel[slot])
        .map((slot) => ({ slot, pilotoId: pilotosSel[slot].id, duracaoAnos: pilotosSel[slot].duracao })),
    };
    confirmarPreTemporada(decisoes);
  };

  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_320px]">
      <div className="flex flex-col gap-4">
        <ListaErros erros={erros} />

        {/* ------------------------- MOTOR ------------------------- */}
        <Card titulo="Contrato de motor">
          {motorVigente ? (
            <ContratoVigenteInfo
              nome={CATALOGO.motores[jogador.contratoMotor.motorId].nome}
              detalhe={`potência ${CATALOGO.motores[jogador.contratoMotor.motorId].potencia} · confiabilidade ${CATALOGO.motores[jogador.contratoMotor.motorId].confiabilidade}`}
              custo={jogador.contratoMotor.custoAnual}
              anosRestantes={anosRestantes(jogador.contratoMotor, ano)}
            />
          ) : (
            <div className="flex flex-col gap-2">
              {Object.values(CATALOGO.motores).map((motor) => (
                <label
                  key={motor.id}
                  className={`flex cursor-pointer items-center gap-3 rounded border p-2 ${
                    motorSel.id === motor.id ? 'border-acento bg-superficie-2' : 'border-borda hover:border-mudo'
                  }`}
                >
                  <input
                    type="radio"
                    name="motor"
                    className="accent-(--color-acento)"
                    checked={motorSel.id === motor.id}
                    onChange={() => setMotorSel({ ...motorSel, id: motor.id })}
                  />
                  <span className="flex-1 font-medium">{motor.nome}</span>
                  <TierBadge tier={motor.tier} />
                  <span className="num w-24 text-right text-sm text-mudo">pot {motor.potencia}</span>
                  <span className="num w-24 text-right text-sm text-mudo">conf {motor.confiabilidade}</span>
                  <span className="num w-24 text-right text-sm">{formatarDinheiro(custoAnualMotor(motor, motorSel.duracao))}/ano</span>
                </label>
              ))}
              <SeletorDuracao
                valor={motorSel.duracao}
                onChange={(duracao) => setMotorSel({ ...motorSel, duracao })}
              />
            </div>
          )}
        </Card>

        {/* ------------------------- PILOTOS ------------------------- */}
        {([0, 1] as const).map((slot) => {
          const contrato = jogador.pilotos[slot];
          const vigente = contratoVigente(contrato, ano);
          const sel = pilotosSel[slot];
          return (
            <Card key={slot} titulo={`Piloto ${slot + 1}`}>
              {vigente ? (
                <ContratoVigenteInfo
                  nome={CATALOGO.pilotos[contrato.pilotoId].nome}
                  detalhe={`quali ${CATALOGO.pilotos[contrato.pilotoId].classificacao} · corrida ${CATALOGO.pilotos[contrato.pilotoId].corrida} · conf ${CATALOGO.pilotos[contrato.pilotoId].confiabilidade}`}
                  custo={contrato.salarioAnual}
                  anosRestantes={anosRestantes(contrato, ano)}
                />
              ) : (
                <div className="flex flex-col gap-2">
                  <p className="text-sm text-alerta">Assento vago — contrate um piloto livre.</p>
                  <div className="max-h-56 overflow-y-auto rounded border border-borda">
                    {estado!.pilotosLivres
                      .filter((id) => id !== pilotosSel[slot === 0 ? 1 : 0]?.id)
                      .map((id) => CATALOGO.pilotos[id])
                      .sort((a, b) => b.corrida - a.corrida)
                      .map((piloto) => (
                        <label
                          key={piloto.id}
                          className={`flex cursor-pointer items-center gap-3 border-b border-borda p-2 last:border-b-0 ${
                            sel?.id === piloto.id ? 'bg-superficie-2' : 'hover:bg-superficie-2/50'
                          }`}
                        >
                          <input
                            type="radio"
                            name={`piloto-${slot}`}
                            className="accent-(--color-acento)"
                            checked={sel?.id === piloto.id}
                            onChange={() => setPilotosSel({ ...pilotosSel, [slot]: { id: piloto.id, duracao: sel?.duracao ?? 2 } })}
                          />
                          <span className="flex-1 text-sm font-medium">{piloto.nome}</span>
                          <span className="num w-20 text-right text-xs text-mudo">quali {piloto.classificacao}</span>
                          <span className="num w-20 text-right text-xs text-mudo">corr {piloto.corrida}</span>
                          <span className="num w-24 text-right text-sm">
                            {formatarDinheiro(salarioAnualPiloto(piloto, sel?.duracao ?? 2))}/ano
                          </span>
                        </label>
                      ))}
                  </div>
                  {sel && (
                    <SeletorDuracao
                      valor={sel.duracao}
                      onChange={(duracao) => setPilotosSel({ ...pilotosSel, [slot]: { ...sel, duracao } })}
                    />
                  )}
                </div>
              )}
            </Card>
          );
        })}

        {/* ------------------------- PATROCÍNIO ------------------------- */}
        <Card titulo="Patrocínio da temporada">
          <div className="flex flex-col gap-2">
            {Object.values(CATALOGO.patrocinadores)
              .sort((a, b) => b.aporte - a.aporte)
              .map((pat) => {
                const bloqueado = estado!.patrocinadoresBloqueados.includes(pat.id);
                const semReputacao = jogador.reputacao < pat.reputacaoMinima;
                const indisponivel = bloqueado || semReputacao;
                return (
                  <label
                    key={pat.id}
                    className={`flex items-center gap-3 rounded border p-2 ${
                      indisponivel
                        ? 'cursor-not-allowed border-borda opacity-45'
                        : patrocinadorId === pat.id
                          ? 'cursor-pointer border-acento bg-superficie-2'
                          : 'cursor-pointer border-borda hover:border-mudo'
                    }`}
                  >
                    <input
                      type="radio"
                      name="patrocinador"
                      className="accent-(--color-acento)"
                      disabled={indisponivel}
                      checked={patrocinadorId === pat.id}
                      onChange={() => setPatrocinadorId(pat.id)}
                    />
                    <span className="flex-1 font-medium">{pat.nome}</span>
                    {pat.meta && (
                      <span className="text-xs text-mudo">
                        meta: top {pat.meta.posicaoConstrutoresMax} (+{formatarDinheiro(pat.meta.bonus)})
                      </span>
                    )}
                    {bloqueado && <span className="text-xs text-negativo">não renovou</span>}
                    {semReputacao && !bloqueado && (
                      <span className="text-xs text-alerta">exige reputação {pat.reputacaoMinima}</span>
                    )}
                    <span className="num w-24 text-right text-sm">{formatarDinheiro(pat.aporte)}</span>
                  </label>
                );
              })}
          </div>
        </Card>
      </div>

      {/* --------------------- PAINEL DE ORÇAMENTO --------------------- */}
      <div className="lg:sticky lg:top-4 lg:self-start">
        <Card titulo="Orçamento da temporada">
          <dl className="flex flex-col gap-1.5 text-sm">
            <LinhaOrcamento nome="Orçamento-base" valor={jogador.orcamentoBase} />
            <LinhaOrcamento nome="Patrocínio" valor={(CATALOGO.patrocinadores[patrocinadorId]?.aporte ?? 0)} />
            <LinhaOrcamento nome="Premiação do ano passado" valor={premiacao} />
            <div className="my-1 border-t border-borda" />
            <LinhaOrcamento nome="Receita total" valor={orcamento.receita} destaque />
            <LinhaOrcamento nome="Motor + salários" valor={-orcamento.gastosFixos} />
            <LinhaOrcamento nome="Desenvolvimento" valor={-investimento} />
            <div className="my-1 border-t border-borda" />
            <div className="flex justify-between font-semibold">
              <dt>Saldo</dt>
              <dd className={`num ${orcamento.saldo < 0 ? 'text-negativo' : 'text-positivo'}`}>
                {formatarDinheiro(orcamento.saldo)}
              </dd>
            </div>
          </dl>

          <div className="mt-4">
            <label htmlFor="investimento" className="rotulo">
              Investimento em desenvolvimento
            </label>
            <input
              id="investimento"
              type="range"
              min={0}
              max={tetoInvestimento}
              step={1_000_000}
              value={Math.min(investimento, tetoInvestimento)}
              onChange={(e) => setInvestimento(Number(e.target.value))}
              className="mt-2 w-full accent-(--color-acento)"
            />
            <p className="num mt-1 text-right text-lg font-bold text-acento">{formatarDinheiro(investimento)}</p>
            <p className="text-right text-xs text-mudo">disponível: {formatarDinheiro(tetoInvestimento)}</p>
          </div>

          {orcamento.mensagem && <p className="mt-3 text-sm text-negativo">{orcamento.mensagem}</p>}

          <Botao
            onClick={confirmar}
            desabilitado={!orcamento.valido}
            className="mt-4 w-full"
          >
            Confirmar e ir para o 1º GP
          </Botao>
        </Card>
      </div>
    </div>
  );
}

function ContratoVigenteInfo(props: { nome: string; detalhe: string; custo: number; anosRestantes: number }) {
  return (
    <div className="flex items-center gap-3">
      <div className="flex-1">
        <p className="font-medium">{props.nome}</p>
        <p className="text-xs text-mudo">{props.detalhe}</p>
      </div>
      <span className="num text-sm">{formatarDinheiro(props.custo)}/ano</span>
      <span className="rounded bg-superficie-2 px-2 py-1 text-xs text-mudo">
        {props.anosRestantes} ano{props.anosRestantes > 1 ? 's' : ''} restante{props.anosRestantes > 1 ? 's' : ''}
      </span>
    </div>
  );
}

function SeletorDuracao(props: { valor: number; onChange: (v: number) => void }) {
  return (
    <div className="flex items-center gap-2 text-sm">
      <span className="text-mudo">Duração do contrato:</span>
      {[1, 2, 3, 4, 5].map((anos) => (
        <button
          key={anos}
          type="button"
          onClick={() => props.onChange(anos)}
          className={`rounded border px-2 py-1 text-xs font-semibold ${
            props.valor === anos ? 'border-acento text-acento' : 'border-borda text-mudo hover:text-texto'
          }`}
        >
          {anos} ano{anos > 1 ? 's' : ''}
        </button>
      ))}
      <span className="ml-auto text-xs text-mudo">contrato mais longo = desconto (até 12%)</span>
    </div>
  );
}

function LinhaOrcamento(props: { nome: string; valor: number; destaque?: boolean }) {
  return (
    <div className={`flex justify-between ${props.destaque ? 'font-semibold' : ''}`}>
      <dt className={props.destaque ? '' : 'text-mudo'}>{props.nome}</dt>
      <dd className={`num ${props.valor < 0 ? 'text-negativo' : ''}`}>{formatarDinheiro(props.valor)}</dd>
    </div>
  );
}
