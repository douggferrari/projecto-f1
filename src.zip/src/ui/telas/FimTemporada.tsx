// ============================================================================
// Fim de temporada: classificação final, premiação, reputação, meta de
// patrocínio, convites de outras equipes e a virada para o ano seguinte.
// ============================================================================

import { useMemo, useState } from 'react';
import { gerarRelatorioFimTemporada } from '../../engine/fimTemporada';
import { anosRestantes } from '../../engine/contratos';
import { CATALOGO } from '../../state/catalogo';
import { useJogo } from '../../state/store';
import { formatarDinheiro } from '../formatar';
import { Botao, Card, TierBadge } from '../componentes';

export function FimTemporada() {
  const { estado, concluirTemporada } = useJogo();
  const [conviteSelecionado, setConviteSelecionado] = useState<string | undefined>();

  const relatorio = useMemo(() => gerarRelatorioFimTemporada(estado!, CATALOGO), [estado]);
  const jogador = estado!.equipes.find((e) => e.ehJogador)!;
  const deltaReputacao = relatorio.jogador.reputacaoDepois - relatorio.jogador.reputacaoAntes;
  const contratosExpirando = jogador.pilotos.filter((c) => anosRestantes(c, estado!.ano + 1) === 0);

  return (
    <div className="flex flex-col gap-4">
      <h1 className="text-xl font-bold">Fim da temporada {estado!.ano}</h1>

      <div className="grid gap-4 lg:grid-cols-[1fr_360px]">
        {/* Classificação final */}
        <Card titulo="Classificação final — construtores">
          <table className="w-full text-sm">
            <tbody>
              {relatorio.classificacao.map(({ equipeId, pontos, posicao }) => {
                const equipe = estado!.equipes.find((e) => e.id === equipeId)!;
                return (
                  <tr
                    key={equipeId}
                    className={`border-t border-borda/60 ${equipe.ehJogador ? 'bg-acento/10' : ''}`}
                  >
                    <td className="num w-8 py-1.5 pr-3">{posicao}</td>
                    <td className="py-1.5 pr-3 font-medium">{equipe.nome}</td>
                    <td className="py-1.5 pr-3"><TierBadge tier={equipe.tier} /></td>
                    <td className="num py-1.5 pr-3 text-right">{pontos} pts</td>
                    <td className="num py-1.5 text-right text-positivo">
                      {formatarDinheiro(relatorio.premiacoes[equipeId])}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </Card>

        <div className="flex flex-col gap-4">
          {/* Resumo do jogador */}
          <Card titulo="Sua temporada">
            <dl className="flex flex-col gap-2 text-sm">
              <div className="flex justify-between">
                <dt className="text-mudo">Posição final</dt>
                <dd className="num font-bold">P{relatorio.jogador.posicao}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-mudo">Expectativa</dt>
                <dd className="num">P{relatorio.jogador.expectativa}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-mudo">Reputação</dt>
                <dd className="num">
                  {Math.round(relatorio.jogador.reputacaoAntes)} →{' '}
                  <span className={deltaReputacao >= 0 ? 'text-positivo' : 'text-negativo'}>
                    {Math.round(relatorio.jogador.reputacaoDepois)}
                  </span>
                </dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-mudo">Premiação</dt>
                <dd className="num text-positivo">{formatarDinheiro(relatorio.premiacoes[jogador.id])}</dd>
              </div>
              {relatorio.jogador.metaPatrocinio && (
                <div className="flex justify-between">
                  <dt className="text-mudo">Meta de patrocínio</dt>
                  <dd className={relatorio.jogador.metaPatrocinio.cumprida ? 'text-positivo' : 'text-negativo'}>
                    {relatorio.jogador.metaPatrocinio.cumprida
                      ? `cumprida (+${formatarDinheiro(relatorio.jogador.metaPatrocinio.bonus)})`
                      : 'não cumprida — sem renovação'}
                  </dd>
                </div>
              )}
              {relatorio.saltoRegulamento && (
                <p className="rounded border border-alerta/40 bg-alerta/10 p-2 text-alerta">
                  ⚠ Novo regulamento na próxima temporada: os níveis de chassi serão
                  normalizados — quem investiu forte no ciclo leva vantagem.
                </p>
              )}
              {contratosExpirando.length > 0 && (
                <p className="text-mudo">
                  Contratos expirando:{' '}
                  {contratosExpirando.map((c) => CATALOGO.pilotos[c.pilotoId].nome).join(', ')}
                </p>
              )}
            </dl>
          </Card>

          {/* Convites */}
          <Card titulo="Convites">
            {relatorio.convites.length === 0 ? (
              <p className="text-sm text-mudo">
                Nenhuma equipe veio bater na sua porta este ano. Reputação alta e
                resultados consistentes destravam convites.
              </p>
            ) : (
              <div className="flex flex-col gap-2">
                {relatorio.convites.map((equipeId) => {
                  const equipe = estado!.equipes.find((e) => e.id === equipeId)!;
                  const selecionado = conviteSelecionado === equipeId;
                  return (
                    <button
                      key={equipeId}
                      type="button"
                      onClick={() => setConviteSelecionado(selecionado ? undefined : equipeId)}
                      className={`flex items-center gap-3 rounded border p-2 text-left ${
                        selecionado ? 'border-acento bg-superficie-2' : 'border-borda hover:border-mudo'
                      }`}
                    >
                      <span className="flex-1 font-medium">{equipe.nome}</span>
                      <TierBadge tier={equipe.tier} />
                      <span className="num text-xs text-mudo">base {formatarDinheiro(equipe.orcamentoBase)}</span>
                    </button>
                  );
                })}
                <p className="text-xs text-mudo">
                  Aceitar significa assumir a equipe na próxima temporada, com o
                  orçamento, carro e contratos dela.
                </p>
              </div>
            )}
          </Card>

          <Botao onClick={() => concluirTemporada(conviteSelecionado)} className="w-full">
            {conviteSelecionado
              ? `Aceitar convite e ir para ${estado!.equipes.find((e) => e.id === conviteSelecionado)!.nome}`
              : `Continuar na ${jogador.nome} em ${estado!.ano + 1}`}
          </Botao>
        </div>
      </div>
    </div>
  );
}
