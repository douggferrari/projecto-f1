// ============================================================================
// IA de gestão das equipes rivais — pré-temporada.
// Não precisa ser esperta; precisa manter a grade viva e competitiva:
//   1. renova o motor expirado (mesmo fornecedor);
//   2. re-assina pilotos expirados se couber, senão contrata o melhor livre;
//   3. investe todo o resíduo em desenvolvimento.
// Funções puras: recebem estado + catálogo e devolvem um estado novo.
// ============================================================================

import { EFICIENCIA_INVESTIMENTO_IA, RESERVA_DESENVOLVIMENTO_IA } from './constantes';
import { contratoVigente, criarContratoMotor, criarContratoPiloto } from './contratos';
import { gastosFixos, receitaTemporada } from './orcamento';
import type { EstadoJogo, Motor, Patrocinador, Piloto } from './tipos';

export interface CatalogoJogo {
  motores: Record<string, Motor>;
  pilotos: Record<string, Piloto>;
  patrocinadores: Record<string, Patrocinador>;
}

/** Nota simples de qualidade de piloto para a IA ranquear contratações. */
function notaPiloto(p: Piloto): number {
  return 0.4 * p.classificacao + 0.5 * p.corrida + 0.1 * p.confiabilidade;
}

/**
 * Aplica a pré-temporada de TODAS as equipes da IA (a do jogador fica
 * intocada — as decisões dela vêm de confirmarPreTemporada).
 * As equipes escolhem na ordem do array (grandes primeiro — prioridade
 * realista na disputa por pilotos livres).
 */
export function aplicarGestaoIA(estado: EstadoJogo, catalogo: CatalogoJogo): EstadoJogo {
  const novo: EstadoJogo = structuredClone(estado);
  const livres = new Set(novo.pilotosLivres);

  for (const equipe of novo.equipes) {
    if (equipe.ehJogador) continue;

    const receita = receitaTemporada(
      equipe,
      catalogo.patrocinadores,
      novo.premiacaoAnterior[equipe.id] ?? 0
    );
    // A IA reserva uma fração da receita para desenvolvimento — não
    // compromete tudo em salários.
    const tetoGastosFixos = receita * (1 - RESERVA_DESENVOLVIMENTO_IA);

    // 1. Motor: renova o mesmo fornecedor por 2 anos se expirou
    if (!contratoVigente(equipe.contratoMotor, novo.ano)) {
      const motor = catalogo.motores[equipe.contratoMotor.motorId];
      equipe.contratoMotor = criarContratoMotor(motor, 2, novo.ano);
    }

    // 2. Pilotos: para cada assento vago, re-assina ou busca no pool
    for (let slot = 0; slot < 2; slot++) {
      const contrato = equipe.pilotos[slot];
      if (contratoVigente(contrato, novo.ano)) continue;

      const outrosGastos = gastosFixos(equipe) - contrato.salarioAnual;
      const cabe = (salario: number) => outrosGastos + salario <= tetoGastosFixos;

      const pilotoAtual = catalogo.pilotos[contrato.pilotoId];
      if (cabe(pilotoAtual.salarioBase) && !livres.has(pilotoAtual.id)) {
        // Re-assina o titular (que não chegou a ir para o pool)
        equipe.pilotos[slot] = criarContratoPiloto(pilotoAtual, 2, novo.ano);
        continue;
      }

      // Busca no pool: o melhor piloto livre que cabe no teto;
      // se nenhum cabe, o mais barato (a vaga não pode ficar aberta)
      const candidatos = [...livres]
        .map((id) => catalogo.pilotos[id])
        .sort((a, b) => notaPiloto(b) - notaPiloto(a));
      const escolhido =
        candidatos.find((p) => cabe(p.salarioBase)) ??
        [...candidatos].sort((a, b) => a.salarioBase - b.salarioBase)[0];

      if (escolhido) {
        livres.delete(escolhido.id);
        livres.add(contrato.pilotoId); // o antigo volta ao mercado
        equipe.pilotos[slot] = criarContratoPiloto(escolhido, 2, novo.ano);
      } else {
        // Pool vazio: re-assina o atual mesmo estourando o teto
        equipe.pilotos[slot] = criarContratoPiloto(pilotoAtual, 1, novo.ano);
      }
    }

    // 3. Investimento: o resíduo vai para desenvolvimento com a eficiência
    // da IA (o desperdício é a brecha que um bom gestor humano explora)
    novo.investimentosAno[equipe.id] = Math.max(
      0,
      Math.round((receita - gastosFixos(equipe)) * EFICIENCIA_INVESTIMENTO_IA)
    );
  }

  novo.pilotosLivres = [...livres];
  return novo;
}
