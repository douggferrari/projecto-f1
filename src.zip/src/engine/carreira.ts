// ============================================================================
// Orquestração da carreira — o loop jogável por cima do motor de simulação.
// Todas as funções são puras (estado entra, estado novo sai); a camada de
// UI/store só chama estas funções e persiste o resultado.
//
// Fluxo: criarCarreira → [pre-temporada: gestão IA + decisões do jogador]
//   → por GP: rodarClassificacao → definirTaticasJogador → rodarCorrida
//   → fim-temporada: gerarRelatorioFimTemporada → aplicarViradaDeAno → volta
// ============================================================================

import { simularClassificacao } from './classificacao';
import { preverCorridaAoVivo } from './corridaAoVivo';
import { contratoVigente, criarContratoMotor, criarContratoPiloto, pilotosLivres } from './contratos';
import { aplicarGestaoIA, type CatalogoJogo } from './gestaoIA';
import { validarOrcamento, formatarDinheiro } from './orcamento';
import { atualizarCampeonatos } from './pontuacao';
import { criarRng, derivarSeed } from './rng';
import { taticaValida } from './taticas';
import type { Circuito, EstadoJogo, Equipe, ResultadoClassificacao, TaticaCorrida } from './tipos';

/** Catálogo completo que o loop precisa (montado na camada de dados/state). */
export interface CatalogoCompleto extends CatalogoJogo {
  circuitos: Record<string, Circuito>;
}

// ---------------------------------------------------------------------------
// Criação de carreira
// ---------------------------------------------------------------------------

export function criarCarreira(
  equipeJogadorId: string,
  seed: number,
  equipesIniciais: Equipe[],
  calendario: string[],
  catalogo: CatalogoCompleto,
  anoInicial: number
): EstadoJogo {
  const equipes = structuredClone(equipesIniciais);
  for (const e of equipes) e.ehJogador = e.id === equipeJogadorId;

  const estado: EstadoJogo = {
    ano: anoInicial,
    seed,
    equipeJogadorId,
    fase: 'pre-temporada',
    gpAtual: 0,
    equipes,
    calendario,
    campeonatoPilotos: {},
    campeonatoConstrutores: {},
    historico: [],
    premiacaoAnterior: {}, // ano 1: sem premiação — todo mundo parte da receita-base
    investimentosAno: {},
    pilotosLivres: pilotosLivres(Object.values(catalogo.pilotos), equipes, anoInicial),
    patrocinadoresBloqueados: [],
  };

  // A IA dos rivais já resolve a pré-temporada dela (contratos + investimento)
  return aplicarGestaoIA(estado, catalogo);
}

// ---------------------------------------------------------------------------
// Pré-temporada do jogador
// ---------------------------------------------------------------------------

export interface DecisoesPreTemporada {
  /** Novo contrato de motor — obrigatório apenas se o atual expirou. */
  motor?: { motorId: string; duracaoAnos: number };
  /** Contratações para assentos vagos (slot 0/1). */
  pilotos?: { slot: 0 | 1; pilotoId: string; duracaoAnos: number }[];
  /** Patrocinador da temporada (sempre escolhido/renovado anualmente). */
  patrocinadorId: string;
  /** Investimento em desenvolvimento (o resíduo flexível). */
  investimento: number;
}

export interface ResultadoConfirmacao {
  estado: EstadoJogo;
  erros: string[];
}

/**
 * Valida e aplica as decisões de pré-temporada do jogador.
 * Se houver erros, o estado devolvido é o original (nada é aplicado)
 * e `erros` explica o que falta cortar/preencher.
 */
export function confirmarPreTemporada(
  estado: EstadoJogo,
  decisoes: DecisoesPreTemporada,
  catalogo: CatalogoCompleto
): ResultadoConfirmacao {
  const novo: EstadoJogo = structuredClone(estado);
  const jogador = novo.equipes.find((e) => e.ehJogador)!;
  const erros: string[] = [];
  const livres = new Set(novo.pilotosLivres);

  // --- Motor ---
  if (decisoes.motor) {
    if (contratoVigente(jogador.contratoMotor, novo.ano)) {
      erros.push('O contrato de motor atual ainda está vigente — não é possível trocar.');
    } else {
      const motor = catalogo.motores[decisoes.motor.motorId];
      if (!motor) erros.push('Fornecedor de motor inválido.');
      else jogador.contratoMotor = criarContratoMotor(motor, decisoes.motor.duracaoAnos, novo.ano);
    }
  }
  if (!contratoVigente(jogador.contratoMotor, novo.ano)) {
    erros.push('A equipe está sem contrato de motor para a temporada.');
  }

  // --- Pilotos ---
  for (const contratacao of decisoes.pilotos ?? []) {
    const atual = jogador.pilotos[contratacao.slot];
    if (contratoVigente(atual, novo.ano)) {
      erros.push(`O assento ${contratacao.slot + 1} ainda tem contrato vigente.`);
      continue;
    }
    if (!livres.has(contratacao.pilotoId)) {
      erros.push('Piloto indisponível: já está sob contrato de outra equipe.');
      continue;
    }
    const piloto = catalogo.pilotos[contratacao.pilotoId];
    jogador.pilotos[contratacao.slot] = criarContratoPiloto(piloto, contratacao.duracaoAnos, novo.ano);
    livres.delete(contratacao.pilotoId);
  }
  for (let slot = 0; slot < 2; slot++) {
    if (!contratoVigente(jogador.pilotos[slot], novo.ano)) {
      erros.push(`O assento ${slot + 1} está sem piloto contratado.`);
    }
  }

  // --- Patrocínio ---
  const patrocinador = catalogo.patrocinadores[decisoes.patrocinadorId];
  if (!patrocinador) {
    erros.push('Escolha um patrocinador para a temporada.');
  } else if (novo.patrocinadoresBloqueados.includes(patrocinador.id)) {
    erros.push(`${patrocinador.nome} não renovou: a meta do ano passado não foi cumprida.`);
  } else if (jogador.reputacao < patrocinador.reputacaoMinima) {
    erros.push(
      `${patrocinador.nome} exige reputação ${patrocinador.reputacaoMinima} (você tem ${jogador.reputacao}).`
    );
  } else {
    jogador.patrocinadorId = patrocinador.id;
  }

  // --- Orçamento (regra dura) ---
  const validacao = validarOrcamento(
    jogador,
    catalogo.patrocinadores,
    novo.premiacaoAnterior[jogador.id] ?? 0,
    decisoes.investimento
  );
  if (!validacao.valido) {
    erros.push(validacao.mensagem ?? `Orçamento estourado em ${formatarDinheiro(validacao.estouro)}.`);
  }

  if (erros.length > 0) return { estado, erros };

  novo.investimentosAno[jogador.id] = decisoes.investimento;
  novo.pilotosLivres = [...livres];
  novo.fase = 'gp-classificacao';
  return { estado: novo, erros: [] };
}

// ---------------------------------------------------------------------------
// Fim de semana de GP
// ---------------------------------------------------------------------------

function circuitoAtual(estado: EstadoJogo, catalogo: CatalogoCompleto): Circuito {
  return catalogo.circuitos[estado.calendario[estado.gpAtual]];
}

/**
 * Calcula o grid da classificação do GP atual SEM commitar — a UI usa
 * para animar a sessão; rodarClassificacao() usa o mesmo caminho.
 */
export function preverClassificacao(
  estado: EstadoJogo,
  catalogo: CatalogoCompleto
): ResultadoClassificacao[] {
  const rng = criarRng(derivarSeed(estado.seed, estado.ano, estado.gpAtual, 0));
  return simularClassificacao(estado.equipes, catalogo, rng);
}

/** Roda a classificação do GP atual → grid definido, fase de estratégia. */
export function rodarClassificacao(estado: EstadoJogo, catalogo: CatalogoCompleto): EstadoJogo {
  const novo: EstadoJogo = structuredClone(estado);
  novo.gridAtual = preverClassificacao(novo, catalogo);
  novo.fase = 'gp-estrategia';
  return novo;
}

/** Registra as táticas dos 2 pilotos do jogador → pronto para a corrida. */
export function definirTaticasJogador(
  estado: EstadoJogo,
  taticas: [TaticaCorrida, TaticaCorrida]
): ResultadoConfirmacao {
  const jogador = estado.equipes.find((e) => e.ehJogador)!;
  const idsJogador = new Set(jogador.pilotos.map((c) => c.pilotoId));
  const erros: string[] = [];

  for (const tatica of taticas) {
    if (!idsJogador.has(tatica.pilotoId)) erros.push('Tática para piloto que não é da sua equipe.');
    else if (!taticaValida(tatica)) {
      erros.push(`Tática inválida: ${tatica.paradas} parada(s) exige ${tatica.paradas + 1} stints.`);
    }
  }
  if (erros.length > 0) return { estado, erros };

  const novo: EstadoJogo = structuredClone(estado);
  novo.taticasJogador = taticas;
  novo.fase = 'gp-corrida';
  return { estado: novo, erros: [] };
}

/**
 * Roda a corrida do GP atual e atualiza campeonatos e calendário.
 * Usa o mesmo caminho da transmissão ao vivo (preverCorridaAoVivo) —
 * o que o jogador assistiu é exatamente o que é commitado.
 */
export function rodarCorrida(estado: EstadoJogo, catalogo: CatalogoCompleto): EstadoJogo {
  const novo: EstadoJogo = structuredClone(estado);
  const circuito = circuitoAtual(novo, catalogo);
  const corrida = preverCorridaAoVivo(novo, catalogo).resultado;

  const atualizado = atualizarCampeonatos(novo.campeonatoPilotos, novo.campeonatoConstrutores, corrida);
  novo.campeonatoPilotos = atualizado.campeonatoPilotos;
  novo.campeonatoConstrutores = atualizado.campeonatoConstrutores;
  novo.historico.push({ circuitoId: circuito.id, grid: novo.gridAtual!, corrida });

  novo.gridAtual = undefined;
  novo.taticasJogador = undefined;
  novo.gpAtual += 1;
  novo.fase = novo.gpAtual < novo.calendario.length ? 'gp-classificacao' : 'fim-temporada';
  return novo;
}

// ---------------------------------------------------------------------------
// Nova pré-temporada (após a virada de ano)
// ---------------------------------------------------------------------------

/** Depois de aplicarViradaDeAno, roda a gestão da IA para o ano novo. */
export function iniciarPreTemporada(estado: EstadoJogo, catalogo: CatalogoCompleto): EstadoJogo {
  return aplicarGestaoIA(estado, catalogo);
}
