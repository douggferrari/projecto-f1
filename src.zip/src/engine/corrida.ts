// ============================================================================
// Simulação de corrida: stints, pneus, degradação, pit stops e DNFs.
// Função pura: recebe grid + táticas + catálogos + RNG, devolve o resultado.
//
// ATENÇÃO (Fase 3): simularCorridaDetalhada expõe os tempos volta a volta
// para a transmissão ao vivo. simularCorrida é um wrapper dela — é o MESMO
// caminho de código, com a mesma ordem de consumo do RNG e a mesma ordem
// de soma em ponto flutuante. O resultado é bit-idêntico ao da Fase 2.
// ============================================================================

import {
  BONUS_POSICAO_GRID,
  CUSTO_PIT_STOP,
  DEGRADACAO_MAXIMA_POR_VOLTA,
  DEGRADACAO_POR_VOLTA,
  FATOR_ERRO_PILOTO,
  FATOR_QUEBRA_MOTOR,
  FATOR_RITMO_TEMPO,
  MODIFICADOR_PNEU,
  PESO_CARRO_CORRIDA,
  PESO_PILOTO_CORRIDA,
  TEMPO_BASE_VOLTA,
  VARIACAO_FORMA,
  VARIACAO_VOLTA,
} from './constantes';
import type { CatalogoSimulacao } from './classificacao';
import { desempenhoCarro } from './desempenho';
import type { RNG } from './rng';
import type {
  Circuito,
  Equipe,
  Pneu,
  ResultadoClassificacao,
  ResultadoCorridaPiloto,
  TaticaCorrida,
} from './tipos';

/**
 * Divide as voltas da corrida em stints de tamanho o mais igual possível.
 * Ex.: 50 voltas em 3 stints → [17, 17, 16].
 */
export function dividirVoltasEmStints(voltas: number, numStints: number): number[] {
  const base = Math.floor(voltas / numStints);
  const sobra = voltas % numStints;
  return Array.from({ length: numStints }, (_, i) => base + (i < sobra ? 1 : 0));
}

/**
 * Tempos (em segundos) de cada volta de um stint.
 * O ritmo efetivo cai a cada volta pela degradação do pneu, e cada volta
 * tem um pequeno ruído aleatório.
 */
export function temposDasVoltasDoStint(
  ritmoBase: number,
  pneu: Pneu,
  voltasDoStint: number,
  desgasteCircuito: number,
  rng: RNG
): number[] {
  const tempos: number[] = [];
  for (let volta = 1; volta <= voltasDoStint; volta++) {
    // A degradação cresce linear com a volta do stint, mas tem um teto —
    // um stint longo demais fica lento, não absurdamente negativo.
    const degradacao = Math.min(
      DEGRADACAO_MAXIMA_POR_VOLTA,
      DEGRADACAO_POR_VOLTA[pneu] * desgasteCircuito * volta
    );
    const ritmoVolta =
      ritmoBase +
      MODIFICADOR_PNEU[pneu] -
      degradacao +
      rng.entre(-VARIACAO_VOLTA, VARIACAO_VOLTA);
    tempos.push(TEMPO_BASE_VOLTA - FATOR_RITMO_TEMPO * ritmoVolta);
  }
  return tempos;
}

/** Tempo total de um stint (soma das voltas, na mesma ordem de sempre). */
export function tempoDoStint(
  ritmoBase: number,
  pneu: Pneu,
  voltasDoStint: number,
  desgasteCircuito: number,
  rng: RNG
): number {
  return temposDasVoltasDoStint(ritmoBase, pneu, voltasDoStint, desgasteCircuito, rng)
    .reduce((total, tempo) => total + tempo, 0);
}

interface CarroNaCorrida {
  pilotoId: string;
  equipeId: string;
  posicaoGrid: number;
  tempoTotal: number;
  dnf: boolean;
  motivoDnf?: 'quebra' | 'erro';
}

/** Detalhe volta a volta de um carro — usado pela transmissão ao vivo. */
export interface DetalheCarroCorrida {
  pilotoId: string;
  equipeId: string;
  posicaoGrid: number;
  dnf: boolean;
  motivoDnf?: 'quebra' | 'erro';
  tatica: TaticaCorrida;
  /** Tempo de cada volta (sem pit e sem bônus de grid). Vazio se DNF. */
  temposVoltas: number[];
  /** Nº de voltas de cada stint (na ordem da tática). */
  voltasPorStint: number[];
}

export interface CorridaDetalhada {
  resultado: ResultadoCorridaPiloto[];
  detalhes: Record<string, DetalheCarroCorrida>; // pilotoId → detalhe
}

/**
 * Simula a corrida completa expondo os tempos volta a volta.
 * - `taticas`: mapa pilotoId → tática. Pilotos sem tática recebem o default
 *   (2 paradas, medium/medium/soft) — a IA define as suas em taticas.ts.
 * - DNFs são sorteados por corrida (quebra de motor e erro de piloto).
 */
export function simularCorridaDetalhada(
  equipes: Equipe[],
  grid: ResultadoClassificacao[],
  taticas: Record<string, TaticaCorrida>,
  circuito: Circuito,
  catalogo: CatalogoSimulacao,
  rng: RNG
): CorridaDetalhada {
  const equipesPorId = new Map(equipes.map((e) => [e.id, e]));
  const numCarros = grid.length;
  const detalhes: Record<string, DetalheCarroCorrida> = {};

  const carros: CarroNaCorrida[] = grid.map((posicaoGrid) => {
    const equipe = equipesPorId.get(posicaoGrid.equipeId)!;
    const motor = catalogo.motores[equipe.contratoMotor.motorId];
    const piloto = catalogo.pilotos[posicaoGrid.pilotoId];
    const tatica = taticas[piloto.id] ?? taticaDefault(piloto.id);

    // --- Sorteio de DNF (uma vez por corrida, por carro) ---
    const chanceQuebra = (100 - motor.confiabilidade) * FATOR_QUEBRA_MOTOR;
    const chanceErro = (100 - piloto.confiabilidade) * FATOR_ERRO_PILOTO;
    const registrarDnf = (motivoDnf: 'quebra' | 'erro'): CarroNaCorrida => {
      detalhes[piloto.id] = {
        pilotoId: piloto.id, equipeId: equipe.id, posicaoGrid: posicaoGrid.posicao,
        dnf: true, motivoDnf, tatica, temposVoltas: [],
        voltasPorStint: dividirVoltasEmStints(circuito.voltas, tatica.stints.length),
      };
      return { pilotoId: piloto.id, equipeId: equipe.id, posicaoGrid: posicaoGrid.posicao, tempoTotal: Infinity, dnf: true, motivoDnf };
    };
    if (rng.chance(chanceQuebra)) return registrarDnf('quebra');
    if (rng.chance(chanceErro)) return registrarDnf('erro');

    // --- Tempo de corrida: soma dos stints + pit stops ---
    // Forma do fim de semana: um sorteio por carro que desloca a corrida
    // inteira (dia bom/dia ruim) — ver comentário em constantes.ts.
    const forma = rng.entre(-VARIACAO_FORMA, VARIACAO_FORMA);
    const ritmoBase =
      PESO_CARRO_CORRIDA * desempenhoCarro(motor, equipe.nivelChassi) +
      PESO_PILOTO_CORRIDA * piloto.corrida +
      forma;

    const voltasPorStint = dividirVoltasEmStints(circuito.voltas, tatica.stints.length);
    // Mesma ordem de RNG e de soma da versão original: stint a stint,
    // volta a volta, subtotal do stint somado ao acumulado.
    const temposPorStint = tatica.stints.map((pneu, i) =>
      temposDasVoltasDoStint(ritmoBase, pneu, voltasPorStint[i], circuito.desgastePneu, rng)
    );
    let tempoTotal = temposPorStint.reduce(
      (soma, tempos) => soma + tempos.reduce((total, tempo) => total + tempo, 0),
      0
    );
    tempoTotal += tatica.paradas * CUSTO_PIT_STOP;

    // Bônus de largada: quem larga na frente corre em pista limpa
    tempoTotal -= BONUS_POSICAO_GRID * (numCarros - posicaoGrid.posicao);

    detalhes[piloto.id] = {
      pilotoId: piloto.id, equipeId: equipe.id, posicaoGrid: posicaoGrid.posicao,
      dnf: false, tatica, temposVoltas: temposPorStint.flat(), voltasPorStint,
    };
    return { pilotoId: piloto.id, equipeId: equipe.id, posicaoGrid: posicaoGrid.posicao, tempoTotal, dnf: false };
  });

  // Ordena: quem completou por tempo; DNFs no fim (mantendo ordem de grid)
  const ordenados = [...carros].sort((a, b) => {
    if (a.dnf !== b.dnf) return a.dnf ? 1 : -1;
    if (a.dnf && b.dnf) return a.posicaoGrid - b.posicaoGrid;
    return a.tempoTotal - b.tempoTotal;
  });

  const resultado = ordenados.map((carro, indice) => ({
    pilotoId: carro.pilotoId,
    equipeId: carro.equipeId,
    posicao: indice + 1,
    pontos: 0, // preenchido em pontuacao.ts
    dnf: carro.dnf,
    motivoDnf: carro.motivoDnf,
    tempoTotal: carro.dnf ? Infinity : Number(carro.tempoTotal.toFixed(3)),
  }));

  return { resultado, detalhes };
}

/** Simula a corrida completa (wrapper da versão detalhada). */
export function simularCorrida(
  equipes: Equipe[],
  grid: ResultadoClassificacao[],
  taticas: Record<string, TaticaCorrida>,
  circuito: Circuito,
  catalogo: CatalogoSimulacao,
  rng: RNG
): ResultadoCorridaPiloto[] {
  return simularCorridaDetalhada(equipes, grid, taticas, circuito, catalogo, rng).resultado;
}

/** Tática padrão: 2 paradas, medium/medium/soft. */
export function taticaDefault(pilotoId: string): TaticaCorrida {
  return { pilotoId, paradas: 2, stints: ['medium', 'medium', 'soft'] };
}
