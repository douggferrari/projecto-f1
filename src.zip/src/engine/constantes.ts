// ============================================================================
// BALANCEAMENTO — todas as constantes de calibragem do jogo em um lugar só.
// Ajuste aqui sem tocar na lógica do motor.
// ============================================================================

import type { Pneu } from './tipos';

// ---------------------------------------------------------------------------
// Desempenho do carro
// desempenhoCarro = PESO_MOTOR * potencia + PESO_CHASSI * nivelChassi
// ---------------------------------------------------------------------------
export const PESO_MOTOR = 0.45;
export const PESO_CHASSI = 0.55;

// ---------------------------------------------------------------------------
// Classificação
// ritmoQuali = PESO_CARRO_QUALI * desempenhoCarro
//            + PESO_PILOTO_QUALI * piloto.classificacao
//            + random(-VARIACAO_QUALI, +VARIACAO_QUALI)
// ---------------------------------------------------------------------------
export const PESO_CARRO_QUALI = 0.7;
export const PESO_PILOTO_QUALI = 0.3;
export const VARIACAO_QUALI = 3; // amplitude do fator sorte (± pontos de ritmo)

// Conversão de ritmo para tempo de volta:
// tempoVolta = TEMPO_BASE_VOLTA - FATOR_RITMO_TEMPO * ritmo
// Esta é a constante que dita o "peso" do rating no resultado: com 0.03,
// o gap de ~31 pontos de ritmo entre o melhor e o pior carro vira ~46s numa
// corrida de 50 voltas (era ~185s com 0.12 — fundo de grid tomava volta).
export const TEMPO_BASE_VOLTA = 90.0; // segundos
export const FATOR_RITMO_TEMPO = 0.03; // segundos ganhos por ponto de ritmo

// ---------------------------------------------------------------------------
// Corrida
// ritmoBase = PESO_CARRO_CORRIDA * desempenhoCarro + PESO_PILOTO_CORRIDA * piloto.corrida
// ---------------------------------------------------------------------------
export const PESO_CARRO_CORRIDA = 0.6;
export const PESO_PILOTO_CORRIDA = 0.4;

// Ruído por volta (± pontos de ritmo). O ruído da corrida inteira cresce
// com a raiz do nº de voltas: o desvio-padrão fica em
// FATOR_RITMO_TEMPO * V/√3 * √voltas ≈ ±3-4s (2σ) por corrida com V=14.
// É o que impede P1 vs P2 do mesmo tier de ser resultado garantido.
export const VARIACAO_VOLTA = 14.0;

// Forma do fim de semana (± pontos de ritmo, UM sorteio por carro por
// corrida). Diferente do ruído por volta — que se dilui na média de ~50
// voltas — a forma desloca a corrida inteira (~±7,5s com 5.0). É o que
// permite a "zebra": um carro médio num grande dia incomodando os grandes.
// Sem este termo, os 3 grandes venceriam 100% das corridas para sempre.
export const VARIACAO_FORMA = 8.0;

// Modificador de ritmo no início do stint, por composto.
// O soft precisa de vantagem grande o bastante para compensar sua
// degradação em stints curtos/pistas de desgaste baixo — é isso que faz
// a escolha de composto depender do circuito.
export const MODIFICADOR_PNEU: Record<Pneu, number> = {
  soft: +6.0,
  medium: 0.0,
  hard: -3.5,
};

// Perda de ritmo acumulada por volta do stint (degradação).
// Calibrada junto com MODIFICADOR_PNEU: o cruzamento soft→medium fica em
// stints de ~20 voltas (desgaste 1.0) e o soft→hard em ~32 voltas.
export const DEGRADACAO_POR_VOLTA: Record<Pneu, number> = {
  soft: 0.7,
  medium: 0.3,
  hard: 0.1,
};

// Teto da perda de ritmo por degradação numa volta (pontos de ritmo).
// Evita que stints muito longos gerem ritmo absurdamente negativo
// (20 pontos ≈ 0,6s/volta de perda máxima).
export const DEGRADACAO_MAXIMA_POR_VOLTA = 20;

// Tempo equivalente perdido em cada pit stop (segundos).
// Precisa ser da mesma ordem que o custo de degradação de um stint,
// senão "menos paradas" domina qualquer escolha de composto.
export const CUSTO_PIT_STOP = 8;

// Bônus de largada: partir na frente vale alguns segundos "virtuais",
// representando pista limpa / dificuldade de ultrapassar.
// tempoTotal -= BONUS_POSICAO_GRID * (numCarros - posicaoGrid)
// Com 0.12, a pole vale ~2,3s sobre o último do grid de 20 carros.
export const BONUS_POSICAO_GRID = 0.12; // segundos por posição ganha no grid

// ---------------------------------------------------------------------------
// Confiabilidade / DNF (probabilidades POR CORRIDA, por carro)
// chance = (100 - confiabilidade) * FATOR
// Ex.: motor com confiabilidade 70 → 30 * 0.006 = 18% de quebra por corrida
// O atrito é o principal mecanismo que abre portas para os tiers de baixo:
// com estes fatores, uma corrida tem ~3 DNFs em média.
// ---------------------------------------------------------------------------
export const FATOR_QUEBRA_MOTOR = 0.006;
export const FATOR_ERRO_PILOTO = 0.004;

// ---------------------------------------------------------------------------
// Pontuação (padrão F1 para os 10 primeiros)
// ---------------------------------------------------------------------------
export const PONTOS_POR_POSICAO = [25, 18, 15, 12, 10, 8, 6, 4, 2, 1];

// ---------------------------------------------------------------------------
// Desenvolvimento do carro (ciclos de 5 anos)
// Ganho anual de chassi com retornos decrescentes:
//   ganho = GANHO_MAXIMO_ANUAL * (1 - e^(-investimento / ESCALA_INVESTIMENTO))
// Ao fim do ciclo (ano 5), "salto de regulamento":
//   novoNivel = NIVEL_POS_REGULAMENTO_BASE
//             + RETENCAO_REGULAMENTO * (nivelAtual - NIVEL_POS_REGULAMENTO_BASE)
//             + BONUS_INVESTIMENTO_CICLO * min(1, investimentoAcumulado / INVESTIMENTO_CICLO_REFERENCIA)
// ---------------------------------------------------------------------------
export const GANHO_MAXIMO_ANUAL = 10;             // pontos de chassi/ano no teto
// ESCALA alta = investir mais continua rendendo mais (menos saturação):
// ganho(30M)=5.8, ganho(60M)=8.2, ganho(120M)=9.7 — orçamento diferencia.
export const ESCALA_INVESTIMENTO = 35_000_000;    // $ p/ ~63% do ganho máximo
export const ANOS_POR_CICLO = 5;
export const NIVEL_POS_REGULAMENTO_BASE = 40;     // piso após troca de regulamento
// O salto de regulamento é A janela de ultrapassagem de quem vem de trás:
// retém pouco do nível antigo e paga muito pelo investimento acumulado no
// ciclo — quem investiu consistente entra no regulamento novo na frente.
export const RETENCAO_REGULAMENTO = 0.2;          // fração do excedente mantida
export const BONUS_INVESTIMENTO_CICLO = 22;       // bônus máx. p/ ciclo bem investido
export const INVESTIMENTO_CICLO_REFERENCIA = 220_000_000; // referência de ciclo "cheio"

// ---------------------------------------------------------------------------
// Premiação de fim de temporada por posição no construtores (1º..10º)
// ---------------------------------------------------------------------------
// Distribuição achatada de propósito: o fundo do grid precisa de fôlego
// para investir, senão "começar pequeno e subir" não fecha a conta.
export const PREMIACAO_CONSTRUTORES = [
  52_000_000, 46_000_000, 41_000_000, 37_000_000, 34_000_000,
  31_000_000, 29_000_000, 27_000_000, 26_000_000, 25_000_000,
];

// ===========================================================================
// FASE 2 — Constantes de gestão (contratos, orçamento, reputação, convites)
// Nada abaixo desta linha afeta a simulação de corrida.
// ===========================================================================

// ---------------------------------------------------------------------------
// Contratos: contrato mais longo dá desconto no custo anual, mas trava.
// custoAnual = base * (1 - DESCONTO_POR_ANO_CONTRATO * (duracaoAnos - 1)),
// limitado a DESCONTO_MAXIMO_CONTRATO. Vale para motor e para pilotos.
// ---------------------------------------------------------------------------
export const DESCONTO_POR_ANO_CONTRATO = 0.04;
export const DESCONTO_MAXIMO_CONTRATO = 0.12; // teto do desconto (contrato de 4+ anos)
export const DURACAO_MAXIMA_CONTRATO = 5;

// ---------------------------------------------------------------------------
// Patrocínio: patrocinadores grandes só assinam com chefes de reputação.
// Mapa aporte → reputação mínima fica em data/patrocinadores.ts; aqui só a
// regra da meta: falhar a meta bloqueia a renovação no ano seguinte.
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// Reputação do chefe (0-100)
// expectativa = min(EXPECTATIVA_POR_TIER[tier], posicaoAnterior + 1)
// delta = (expectativa - posicaoFinal) * REPUTACAO_POR_POSICAO, com teto.
// ---------------------------------------------------------------------------
export const EXPECTATIVA_POR_TIER: Record<'pequena' | 'media' | 'grande', number> = {
  pequena: 9, // fundo do grid: escapar da última posição já cumpre a expectativa
  media: 6,
  grande: 2,
};
// A posição anterior só endurece a expectativa com 2 posições de folga —
// melhorar devagar não pode virar punição de reputação.
export const FOLGA_EXPECTATIVA_POSICAO_ANTERIOR = 2;
export const REPUTACAO_POR_POSICAO = 3; // pontos de reputação por posição acima/abaixo
export const REPUTACAO_DELTA_MAXIMO = 12; // teto de variação por temporada

// ---------------------------------------------------------------------------
// Convites de outras equipes no fim da temporada.
// Uma equipe de tier igual/superior convida se a reputação do jogador
// alcançar o limiar do tier dela E ela tiver terminado abaixo da
// expectativa do próprio tier (equipe frustrada procura chefe novo).
// ---------------------------------------------------------------------------
export const REPUTACAO_MINIMA_CONVITE: Record<'pequena' | 'media' | 'grande', number> = {
  pequena: 0,
  media: 60,
  grande: 80,
};

// ---------------------------------------------------------------------------
// IA de gestão dos rivais: fração da receita que a IA reserva para
// desenvolvimento antes de decidir salários (não torra tudo em piloto).
// ---------------------------------------------------------------------------
export const RESERVA_DESENVOLVIMENTO_IA = 0.25;

// Eficiência de investimento da IA: fração do resíduo que vira de fato
// desenvolvimento (o resto é desperdício de gestão). É a vantagem
// estrutural de um bom chefe humano sobre a burocracia dos rivais — sem
// ela, o orçamento-base maior das equipes grandes torna a ascensão de uma
// equipe pequena impossível em qualquer horizonte.
export const EFICIENCIA_INVESTIMENTO_IA = 0.35;
