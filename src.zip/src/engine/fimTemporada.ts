// ============================================================================
// Fim de temporada — funções puras.
// Ordem de aplicação (aplicarViradaDeAno):
//   1. premiação por posição no construtores (+ meta de patrocínio do jogador)
//   2. desenvolvimento do carro (aplicarDesenvolvimento, ciclo de 5 anos)
//   3. reputação do jogador (expectativa por tier/posição anterior)
//   4. convites de outras equipes
//   5. expiração de contratos → pilotos voltam ao pool
//   6. virada: ano++, zera campeonatos/histórico, fase pre-temporada
// ============================================================================

import {
  EXPECTATIVA_POR_TIER,
  FOLGA_EXPECTATIVA_POSICAO_ANTERIOR,
  PREMIACAO_CONSTRUTORES,
  REPUTACAO_DELTA_MAXIMO,
  REPUTACAO_MINIMA_CONVITE,
  REPUTACAO_POR_POSICAO,
} from './constantes';
import { contratoVigente, pilotosLivres } from './contratos';
import { aplicarDesenvolvimento, limitar0a100 } from './desempenho';
import type { CatalogoJogo } from './gestaoIA';
import { classificarCampeonato } from './pontuacao';
import type { EstadoJogo, Equipe, Tier } from './tipos';

const ORDEM_TIER: Record<Tier, number> = { pequena: 0, media: 1, grande: 2 };

export interface RelatorioFimTemporada {
  classificacao: { equipeId: string; pontos: number; posicao: number }[];
  premiacoes: Record<string, number>; // equipeId → premiação (+ bônus de meta)
  jogador: {
    posicao: number;
    expectativa: number;
    reputacaoAntes: number;
    reputacaoDepois: number;
    metaPatrocinio?: { patrocinadorId: string; cumprida: boolean; bonus: number };
  };
  convites: string[]; // equipeIds que querem contratar o chefe
  saltoRegulamento: boolean; // este fim de temporada fecha o ciclo de 5 anos?
}

function equipeJogador(estado: EstadoJogo): Equipe {
  return estado.equipes.find((e) => e.id === estado.equipeJogadorId)!;
}

/** Posições finais do construtores (equipes sem ponto entram no fim). */
export function classificacaoConstrutores(
  estado: EstadoJogo
): { equipeId: string; pontos: number; posicao: number }[] {
  const pontuadas = classificarCampeonato(estado.campeonatoConstrutores);
  const idsPontuados = new Set(pontuadas.map((p) => p.id));
  const semPonto = estado.equipes.filter((e) => !idsPontuados.has(e.id));
  return [
    ...pontuadas.map((p) => ({ equipeId: p.id, pontos: p.pontos })),
    ...semPonto.map((e) => ({ equipeId: e.id, pontos: 0 })),
  ].map((x, i) => ({ ...x, posicao: i + 1 }));
}

/**
 * Expectativa de posição do jogador: a do tier, endurecida pela posição
 * anterior com folga — quem terminou P4 num time pequeno passa a ter
 * expectativa P6, não P4 (melhora sustentada sem catraca punitiva).
 */
export function expectativaJogador(estado: EstadoJogo): number {
  const base = EXPECTATIVA_POR_TIER[equipeJogador(estado).tier];
  return estado.posicaoAnteriorJogador !== undefined
    ? Math.min(base, estado.posicaoAnteriorJogador + FOLGA_EXPECTATIVA_POSICAO_ANTERIOR)
    : base;
}

/**
 * Gera o relatório do fim de temporada (leitura pura — nada é aplicado).
 * A UI mostra este relatório e o jogador decide sobre convites; depois
 * aplicarViradaDeAno() efetiva tudo.
 */
export function gerarRelatorioFimTemporada(
  estado: EstadoJogo,
  catalogo: CatalogoJogo
): RelatorioFimTemporada {
  const classificacao = classificacaoConstrutores(estado);
  const jogador = equipeJogador(estado);
  const posicaoJogador = classificacao.find((c) => c.equipeId === jogador.id)!.posicao;

  // 1. Premiações
  const premiacoes: Record<string, number> = {};
  for (const { equipeId, posicao } of classificacao) {
    premiacoes[equipeId] = PREMIACAO_CONSTRUTORES[posicao - 1] ?? PREMIACAO_CONSTRUTORES.at(-1)!;
  }

  // Meta de patrocínio (só do jogador nesta fase)
  const patrocinador = catalogo.patrocinadores[jogador.patrocinadorId];
  let metaPatrocinio: RelatorioFimTemporada['jogador']['metaPatrocinio'];
  if (patrocinador?.meta) {
    const cumprida = posicaoJogador <= patrocinador.meta.posicaoConstrutoresMax;
    metaPatrocinio = {
      patrocinadorId: patrocinador.id,
      cumprida,
      bonus: cumprida ? patrocinador.meta.bonus : 0,
    };
    if (cumprida) premiacoes[jogador.id] += patrocinador.meta.bonus;
  }

  // 3. Reputação
  const expectativa = expectativaJogador(estado);
  const delta = Math.max(
    -REPUTACAO_DELTA_MAXIMO,
    Math.min(REPUTACAO_DELTA_MAXIMO, (expectativa - posicaoJogador) * REPUTACAO_POR_POSICAO)
  );
  const reputacaoDepois = limitar0a100(jogador.reputacao + delta);

  // 4. Convites: equipes de tier igual/superior, frustradas com a própria
  // temporada, cujo limiar de reputação o jogador alcançou
  const convites = estado.equipes
    .filter((e) => {
      if (e.id === jogador.id) return false;
      if (ORDEM_TIER[e.tier] < ORDEM_TIER[jogador.tier]) return false;
      if (reputacaoDepois < REPUTACAO_MINIMA_CONVITE[e.tier]) return false;
      const posicao = classificacao.find((c) => c.equipeId === e.id)!.posicao;
      return posicao > EXPECTATIVA_POR_TIER[e.tier]; // abaixo da expectativa do tier dela
    })
    .map((e) => e.id);

  return {
    classificacao,
    premiacoes,
    jogador: {
      posicao: posicaoJogador,
      expectativa,
      reputacaoAntes: jogador.reputacao,
      reputacaoDepois,
      metaPatrocinio,
    },
    convites,
    saltoRegulamento: jogador.cicloDesenvolvimento.anoDoCiclo >= 5,
  };
}

/**
 * Efetiva a virada de ano. `conviteAceito` é o id da equipe para onde o
 * jogador vai (precisa estar no relatório), ou undefined para ficar.
 */
export function aplicarViradaDeAno(
  estado: EstadoJogo,
  catalogo: CatalogoJogo,
  conviteAceito?: string
): EstadoJogo {
  const relatorio = gerarRelatorioFimTemporada(estado, catalogo);
  const novo: EstadoJogo = structuredClone(estado);
  const novoAno = novo.ano + 1;

  // 1. Premiação vira receita do ano seguinte
  novo.premiacaoAnterior = relatorio.premiacoes;

  // 2. Desenvolvimento e ciclo de 5 anos
  for (const equipe of novo.equipes) {
    const resultado = aplicarDesenvolvimento(
      equipe.nivelChassi,
      equipe.cicloDesenvolvimento,
      novo.investimentosAno[equipe.id] ?? 0
    );
    equipe.nivelChassi = resultado.novoNivelChassi;
    equipe.cicloDesenvolvimento = resultado.novoCiclo;
  }

  // 3. Reputação do jogador
  const jogador = novo.equipes.find((e) => e.id === novo.equipeJogadorId)!;
  jogador.reputacao = relatorio.jogador.reputacaoDepois;

  // Meta de patrocínio falhada → sem renovação com este patrocinador
  novo.patrocinadoresBloqueados =
    relatorio.jogador.metaPatrocinio && !relatorio.jogador.metaPatrocinio.cumprida
      ? [relatorio.jogador.metaPatrocinio.patrocinadorId]
      : [];

  // 4. Convite aceito → troca de equipe (herda orçamento/carro/contratos)
  if (conviteAceito && relatorio.convites.includes(conviteAceito)) {
    const destino = novo.equipes.find((e) => e.id === conviteAceito)!;
    destino.reputacao = jogador.reputacao; // a reputação é do chefe
    jogador.reputacao = 50;                // a equipe antiga recomeça neutra
    jogador.ehJogador = false;
    destino.ehJogador = true;
    novo.equipeJogadorId = destino.id;
    novo.patrocinadoresBloqueados = []; // o bloqueio era da relação antiga
  }

  // 5. Contratos: quem expirou volta ao pool (a vigência é derivada do ano)
  novo.pilotosLivres = pilotosLivres(Object.values(catalogo.pilotos), novo.equipes, novoAno);

  // 6. Virada
  novo.posicaoAnteriorJogador = novo.equipes.find((e) => e.ehJogador)!.id === estado.equipeJogadorId
    ? relatorio.jogador.posicao
    : undefined; // trocou de equipe: expectativa nova vem só do tier
  novo.ano = novoAno;
  novo.fase = 'pre-temporada';
  novo.gpAtual = 0;
  novo.campeonatoPilotos = {};
  novo.campeonatoConstrutores = {};
  novo.historico = [];
  novo.investimentosAno = {};
  novo.gridAtual = undefined;
  novo.taticasJogador = undefined;
  novo.convites = undefined;

  return novo;
}

// Reexporta para conveniência de quem consome o relatório
export { contratoVigente };
