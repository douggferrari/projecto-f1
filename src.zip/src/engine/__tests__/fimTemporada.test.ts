import { describe, expect, it } from 'vitest';
import { EXPECTATIVA_POR_TIER, PREMIACAO_CONSTRUTORES, REPUTACAO_DELTA_MAXIMO } from '../constantes';
import { classificacaoConstrutores, expectativaJogador, gerarRelatorioFimTemporada } from '../fimTemporada';
import type { CatalogoJogo } from '../gestaoIA';
import type { EstadoJogo } from '../tipos';
import { equipeTeste, motorTeste, pilotoTeste } from './fixtures';

// Cenário sintético: 3 equipes (grande frustrada, média, pequena do jogador)
function estadoSintetico(pontos: Record<string, number>, reputacao = 50): EstadoJogo {
  const grande = { ...equipeTeste('eq-g', 'm1', ['g1', 'g2'], 85), tier: 'grande' as const };
  const media = { ...equipeTeste('eq-m', 'm1', ['m1p', 'm2p'], 65), tier: 'media' as const };
  const pequena = {
    ...equipeTeste('eq-p', 'm1', ['p1p', 'p2p'], 45),
    tier: 'pequena' as const,
    ehJogador: true,
    reputacao,
  };
  return {
    ano: 2026,
    seed: 1,
    equipeJogadorId: 'eq-p',
    fase: 'fim-temporada',
    gpAtual: 12,
    equipes: [grande, media, pequena],
    calendario: [],
    campeonatoPilotos: {},
    campeonatoConstrutores: pontos,
    historico: [],
    premiacaoAnterior: {},
    investimentosAno: {},
    pilotosLivres: [],
    patrocinadoresBloqueados: [],
  };
}

const catalogo: CatalogoJogo = {
  motores: { m1: motorTeste() },
  pilotos: Object.fromEntries(
    ['g1', 'g2', 'm1p', 'm2p', 'p1p', 'p2p'].map((id) => [id, pilotoTeste({ id })])
  ),
  patrocinadores: {
    'pat-x': { id: 'pat-x', nome: 'Pat X', aporte: 10_000_000, reputacaoMinima: 0 },
    'pat-meta': {
      id: 'pat-meta', nome: 'Pat Meta', aporte: 20_000_000, reputacaoMinima: 0,
      meta: { posicaoConstrutoresMax: 2, bonus: 5_000_000 },
    },
  },
};

describe('classificacaoConstrutores', () => {
  it('ordena por pontos e coloca equipes sem ponto no fim', () => {
    const estado = estadoSintetico({ 'eq-m': 30, 'eq-g': 80 });
    expect(classificacaoConstrutores(estado).map((c) => c.equipeId)).toEqual([
      'eq-g', 'eq-m', 'eq-p',
    ]);
  });
});

describe('expectativa e reputação', () => {
  it('a expectativa vem do tier e endurece com a posição anterior (com folga)', () => {
    const estado = estadoSintetico({});
    expect(expectativaJogador(estado)).toBe(EXPECTATIVA_POR_TIER.pequena);
    estado.posicaoAnteriorJogador = 2;
    expect(expectativaJogador(estado)).toBe(4); // anterior + folga de 2
  });

  it('superar a expectativa sobe a reputação (com teto de variação)', () => {
    // Jogador (pequena, expectativa 8) termina em 1º → delta positivo máximo
    const estado = estadoSintetico({ 'eq-p': 100, 'eq-g': 50, 'eq-m': 30 });
    const r = gerarRelatorioFimTemporada(estado, catalogo);
    expect(r.jogador.posicao).toBe(1);
    expect(r.jogador.reputacaoDepois - r.jogador.reputacaoAntes).toBe(REPUTACAO_DELTA_MAXIMO);
  });

  it('ficar abaixo da expectativa derruba a reputação', () => {
    // Numa equipe grande (expectativa 2), terminar em 3º é fracasso
    const estado = estadoSintetico({ 'eq-g': 80, 'eq-m': 30 });
    const jogador = estado.equipes.find((e) => e.ehJogador)!;
    jogador.tier = 'grande';
    const r = gerarRelatorioFimTemporada(estado, catalogo);
    expect(r.jogador.posicao).toBe(3);
    expect(r.jogador.reputacaoDepois).toBeLessThan(r.jogador.reputacaoAntes);
  });
});

describe('convites', () => {
  it('equipe de tier superior frustrada convida quando a reputação alcança o limiar', () => {
    // Grande (expectativa 2) termina em 3º = frustrada; jogador vence com reputação alta
    const estado = estadoSintetico({ 'eq-p': 100, 'eq-m': 50, 'eq-g': 10 }, 75);
    const r = gerarRelatorioFimTemporada(estado, catalogo);
    expect(r.jogador.reputacaoDepois).toBeGreaterThanOrEqual(80);
    expect(r.convites).toContain('eq-g');
  });

  it('sem reputação suficiente não há convite', () => {
    const estado = estadoSintetico({ 'eq-p': 100, 'eq-m': 50, 'eq-g': 10 }, 30);
    const r = gerarRelatorioFimTemporada(estado, catalogo);
    expect(r.convites).toEqual([]);
  });
});

describe('meta de patrocínio', () => {
  it('meta cumprida soma o bônus à premiação do jogador', () => {
    const estado = estadoSintetico({ 'eq-p': 100, 'eq-g': 50, 'eq-m': 30 });
    estado.equipes.find((e) => e.ehJogador)!.patrocinadorId = 'pat-meta';
    const r = gerarRelatorioFimTemporada(estado, catalogo);
    expect(r.jogador.metaPatrocinio?.cumprida).toBe(true);
    // Premiação de P1 + bônus de 5M
    expect(r.premiacoes['eq-p']).toBe(PREMIACAO_CONSTRUTORES[0] + 5_000_000);
  });

  it('meta falhada não dá bônus', () => {
    const estado = estadoSintetico({ 'eq-g': 80, 'eq-m': 30 }); // jogador P3
    estado.equipes.find((e) => e.ehJogador)!.patrocinadorId = 'pat-meta';
    const r = gerarRelatorioFimTemporada(estado, catalogo);
    expect(r.jogador.metaPatrocinio?.cumprida).toBe(false);
    expect(r.premiacoes['eq-p']).toBe(PREMIACAO_CONSTRUTORES[2]); // só a premiação de P3
  });
});
