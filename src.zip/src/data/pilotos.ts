// ============================================================================
// Pool de pilotos (nomes fictícios) — 24 pilotos: 20 titulares + 4 reservas.
// Ratings e salários coerentes com o "tier" implícito de cada um.
// ============================================================================

import type { Piloto } from '../engine/tipos';

export const PILOTOS: Piloto[] = [
  // --- Elite (salários altos) ---
  { id: 'pil-vantorre', nome: 'Lucas Vantorre', classificacao: 95, corrida: 94, confiabilidade: 92, salarioBase: 24_000_000 },
  { id: 'pil-okada', nome: 'Kenji Okada', classificacao: 93, corrida: 95, confiabilidade: 90, salarioBase: 22_000_000 },
  { id: 'pil-moreau', nome: 'Théo Moreau', classificacao: 92, corrida: 90, confiabilidade: 88, salarioBase: 19_000_000 },
  { id: 'pil-castellani', nome: 'Bruno Castellani', classificacao: 90, corrida: 91, confiabilidade: 85, salarioBase: 17_000_000 },
  // --- Muito bons ---
  { id: 'pil-silveira', nome: 'Rafael Silveira', classificacao: 88, corrida: 87, confiabilidade: 86, salarioBase: 13_000_000 },
  { id: 'pil-nystrom', nome: 'Erik Nyström', classificacao: 87, corrida: 88, confiabilidade: 90, salarioBase: 12_500_000 },
  { id: 'pil-duarte', nome: 'Gonçalo Duarte', classificacao: 86, corrida: 85, confiabilidade: 82, salarioBase: 11_000_000 },
  { id: 'pil-kowalski', nome: 'Adam Kowalski', classificacao: 85, corrida: 86, confiabilidade: 87, salarioBase: 10_500_000 },
  // --- Sólidos de meio de grid ---
  { id: 'pil-herrera', nome: 'Diego Herrera', classificacao: 83, corrida: 82, confiabilidade: 84, salarioBase: 8_000_000 },
  { id: 'pil-vandenberg', nome: 'Max van den Berg', classificacao: 82, corrida: 83, confiabilidade: 80, salarioBase: 7_500_000 },
  { id: 'pil-rocha', nome: 'Thiago Rocha', classificacao: 81, corrida: 80, confiabilidade: 85, salarioBase: 6_500_000 },
  { id: 'pil-leclerq', nome: 'Julien Leclerq', classificacao: 80, corrida: 81, confiabilidade: 78, salarioBase: 6_000_000 },
  { id: 'pil-ferran', nome: 'Marc Ferran', classificacao: 79, corrida: 79, confiabilidade: 83, salarioBase: 5_500_000 },
  { id: 'pil-yamada', nome: 'Sora Yamada', classificacao: 78, corrida: 80, confiabilidade: 81, salarioBase: 5_000_000 },
  // --- Fundo de grid / em ascensão ---
  { id: 'pil-obrien', nome: 'Liam O’Brien', classificacao: 76, corrida: 75, confiabilidade: 79, salarioBase: 3_800_000 },
  { id: 'pil-santoro', nome: 'Enzo Santoro', classificacao: 75, corrida: 77, confiabilidade: 74, salarioBase: 3_500_000 },
  { id: 'pil-almeida', nome: 'Vitor Almeida', classificacao: 74, corrida: 73, confiabilidade: 80, salarioBase: 3_000_000 },
  { id: 'pil-petrov', nome: 'Nikolai Petrov', classificacao: 73, corrida: 74, confiabilidade: 72, salarioBase: 2_800_000 },
  { id: 'pil-mbeki', nome: 'Sipho Mbeki', classificacao: 72, corrida: 73, confiabilidade: 77, salarioBase: 2_500_000 },
  { id: 'pil-lindqvist', nome: 'Oskar Lindqvist', classificacao: 71, corrida: 70, confiabilidade: 75, salarioBase: 2_200_000 },
  // --- Reservas / novatos baratos (potencial de evolução: fase 5) ---
  { id: 'pil-carvalho', nome: 'Pedro Carvalho', classificacao: 69, corrida: 71, confiabilidade: 73, salarioBase: 1_500_000 },
  { id: 'pil-nakamura', nome: 'Rin Nakamura', classificacao: 68, corrida: 69, confiabilidade: 76, salarioBase: 1_300_000 },
  { id: 'pil-weiss', nome: 'Jonas Weiss', classificacao: 67, corrida: 68, confiabilidade: 70, salarioBase: 1_100_000 },
  { id: 'pil-fontana', nome: 'Aldo Fontana', classificacao: 66, corrida: 67, confiabilidade: 74, salarioBase: 1_000_000 },
];

export const PILOTOS_POR_ID: Record<string, Piloto> = Object.fromEntries(
  PILOTOS.map((p) => [p.id, p])
);
